﻿using NUnit.Framework;

using System;
using System.Collections.Generic;
using System.Text;

namespace TestApp.Tests;

public class CountCharactersTests
{
    [Test]
    public void Test_Count_WithEmptyList_ShouldReturnEmptyString()
    {
        // Arrange
        List<string> input = new ();

        // Act
        string result = CountCharacters.Count(input);

        // Assert
        Assert.That(result, Is.Empty);
    }

    // TODO: finish test
    [Test]
    public void Test_Count_WithNoCharacters_ShouldReturnEmptyString()
    {
        // Arrange
        List<string> input = new List<string> { "", "", "" }; 

        // Act
        string result = CountCharacters.Count(input);

        // Assert
        Assert.That(result, Is.Empty);
    }

    [Test]
    public void Test_Count_WithSingleCharacter_ShouldReturnCountString()
    {
        // Arrange
        List<string> input = new() { "A" };

        // Act
        string result = CountCharacters.Count(input);

        // Assert
        Assert.That(result, Is.EqualTo("A -> 1"));
    }

    [Test]
    public void Test_Count_WithMultipleCharacters_ShouldReturnCountString()
    {
        // Arrange
        List<string> input = new() { "AABB", "BBCC", "AABBCD" };

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("A -> 4");
        sb.AppendLine("B -> 6");
        sb.AppendLine("C -> 3");
        sb.AppendLine("D -> 1");

        string expected = sb.ToString().Trim();

        // Act
        string result = CountCharacters.Count(input);

        // Assert
        Assert.That(result, Is.EqualTo(expected));
    }

    [Test]
    public void Test_Count_WithSpecialCharacters_ShouldReturnCountString()
    {
        // Arrange
        List<string> input = new() { "Aa2323!", "@BbCC", "$$aABBCd" };

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("A -> 2");
        sb.AppendLine("a -> 2");
        sb.AppendLine("2 -> 2");
        sb.AppendLine("3 -> 2");
        sb.AppendLine("! -> 1");
        sb.AppendLine("@ -> 1");
        sb.AppendLine("B -> 3");
        sb.AppendLine("b -> 1");
        sb.AppendLine("C -> 3");
        sb.AppendLine("$ -> 2");      
        sb.AppendLine("d -> 1");

        string expected = sb.ToString().Trim();

        // Act
        string result = CountCharacters.Count(input);

        // Assert
        Assert.That(result, Is.EqualTo(expected));
    }

    [Test]
    public void Test_Count_WithUpperCaseAndNumbersAsCharacters_ShouldReturnCountString()
    {
        // Arrange
        List<string> input = new() { "Aa2323!", "@BbCqC", "$$aA2BBCd", "CBA231", "bcA321" };

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("A -> 4");
        sb.AppendLine("a -> 2");
        sb.AppendLine("2 -> 5");
        sb.AppendLine("3 -> 4");
        sb.AppendLine("! -> 1");
        sb.AppendLine("@ -> 1");
        sb.AppendLine("B -> 4");
        sb.AppendLine("b -> 2");
        sb.AppendLine("C -> 4");
        sb.AppendLine("q -> 1");
        sb.AppendLine("$ -> 2");
        sb.AppendLine("d -> 1");
        sb.AppendLine("1 -> 2");
        sb.AppendLine("c -> 1");

        string expected = sb.ToString().Trim();

        // Act
        string result = CountCharacters.Count(input);

        // Assert
        Assert.That(result, Is.EqualTo(expected));
    }
}
