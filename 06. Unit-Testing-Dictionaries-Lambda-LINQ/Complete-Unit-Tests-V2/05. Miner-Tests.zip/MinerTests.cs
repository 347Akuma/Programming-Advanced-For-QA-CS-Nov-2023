﻿using NUnit.Framework;

using System;

namespace TestApp.Tests;

public class MinerTests
{
    [Test]
    public void Test_Mine_WithEmptyInput_ShouldReturnEmptyString()
    {
        //Arrange
        string[] input = new string[0];

        //Act
        string result = Miner.Mine(input);

        //Assert
        Assert.That(result, Is.Empty);
    }

    
    [Test]
    public void Test_Mine_WithMixedCaseResources_ShouldBeCaseInsensitive()
    {
        // Arrange
        string[] input = { "GOLD 8", "sILVEr 30", "gOlD 8", "plAtInUm 2" };

        // Act
        string result = Miner.Mine(input);

        // Assert
        Assert.That(result, Is.EqualTo($"gold -> 16{Environment.NewLine}silver -> 30{Environment.NewLine}platinum -> 2"));
    }

    [Test]
    public void Test_Mine_WithDifferentResources_ShouldReturnResourceCounts()
    {
        // Arrange
        string[] input = { "Gold 800000000", "Silver 300000000","Gold 40", "Platinum 200", "Blackrock 1500", "neznambrat 200" };

        // Act
        string result = Miner.Mine(input);

        // Assert
        Assert.That(result, Is.EqualTo("gold -> 800000040\r\nsilver -> 300000000\r\nplatinum -> 200\r\nblackrock -> 1500\r\nneznambrat -> 200"));
    }
}
